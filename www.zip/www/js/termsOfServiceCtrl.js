angular.module('app.controllers.termsOfService', [])

    .controller('TermsOfServiceCtrl', function($scope) {
    	$scope.activeListItem = 'documents'
    });

